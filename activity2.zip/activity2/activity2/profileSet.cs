﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace activity2
{
    public class profileSet
    {
        public string id_Number;
        public string name;
        public string sex;
        public string birthDate;
        public string civilStatus;

    }
}
